/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ZTERmodel;

/**
 *
 * @author haseena
 */
class MovieData {

    MovieData(String string, String string1, String string2, String string3, Date date) {
    }
    
}
